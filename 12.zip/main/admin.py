from django.contrib import admin
from . import models
# Register your models here.


admin.site.register(models.Banner)
admin.site.register(models.AboutUs)
admin.site.register(models.Contact)
admin.site.register(models.Service)
admin.site.register(models.Blog)